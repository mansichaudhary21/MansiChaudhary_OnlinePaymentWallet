package com.capgemini.onlinewalletapp.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedHashSet;

public class CreateWalletUser implements Serializable
{
	
	
	
		/*--------PhoneNumberCheck------*/
		public boolean validate(String phnNo) 
		{
	       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
			int flag=0;
			int i=0;   
			if(phnNo.length()==10)//Length check
			{
				while(i<phnNo.length())
				{
					char c=phnNo.charAt(i);
					if(!(c>='0'&&c<='9'))
					{
						flag=1;
						break;
					}
					i++;
				} 
				if(flag==1)
				{
					System.out.println("Please fill digits only");
				}
			}//End if
			else
			{
				System.out.println("Length is shorter/greater than 10 digits");
				flag=1;
			}
			if(flag==1)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		  
		/*--------PasswordCheck------*/
		public boolean validatePass(String password)
		{
			int flag=0;
			if(password.length() >= 8 && password.length() <= 16)
			{
				flag=1;
			}
			else
			{
				System.out.println("Please give atleast 8 characters or maximum 16 characters.");
			}
			if(flag == 1)
			{
				return true;
			}
			else
			{
				return false;
			}
				
		 }
		
		
		
	
}
	
	

