package com.capgemini.onlinewalletapp.service;

import com.capgemini.onlinewalletapp.dto.*;

import java.util.*;

public class AddAmount{
	
	double newamount = 0;
	WalletAccounts obj = new WalletAccounts();
	public double addBalance(double amount) {
		// TODO Auto-generated method stub
		
		if(amount<0)
		{
			System.out.println("Invalid amount to add");
		}
		else
		{	
			//obj.accountBalance = obj.accountBalance + amount;
			//obj.accountBalance = 
			//return obj.accountBalance;
			newamount=obj.getAccountBalance();
            newamount+=amount;
            obj.setAccountBalance(newamount);
		}
			
		//return obj.accountBalance;
		return newamount;
	}
		
		
	

}
