package com.capgemini.onlinewalletapp.service;

public class TransferFunds {

	public void transferAmount() {
		// TODO Auto-generated method stub
		
	}

	

}
