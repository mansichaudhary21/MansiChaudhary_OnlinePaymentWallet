package com.capgemini.onlinewalletapp.dto;

import java.util.*;

import java.io.Serializable;

public class WalletUser implements Serializable{
	
	private int userId;
	private String userName;
	private String phoneNumber;
	private String password;
	private String loginName;
	
	public WalletUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	  public WalletUser(int UserId, String userName, String phoneNumber, String password,String loginName) 
	  { 
		  super(); 
		  this.userId = UserId;
		  this.userName = userName; 
		  this.phoneNumber = phoneNumber; 
		  this.password = password; 
		  this.loginName = loginName; 
	  }
	 

	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getLoginName() {
		return loginName;
	}


	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}


	public String toString()
	{
		return userName + "\n" + phoneNumber + "\n" + password + "\n" + loginName;
	}
	

}
