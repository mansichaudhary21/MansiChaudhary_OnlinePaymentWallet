package com.capgemini.onlinewalletapp.service;

import com.capgemini.onlinewalletapp.dto.WalletAccounts;
import com.capgemini.onlinewalletapp.main.WalletMainClass;

public class ShowBalance {

	public void displayBalance() {
		// TODO Auto-generated method stub
		
		//System.out.println("User Name:" + loginName);
		AddAmount _obj = new AddAmount();
		WalletAccounts wa = new WalletAccounts();
		System.out.println("Current Balance:" + wa.getAccountBalance());
		
	}
	

}
