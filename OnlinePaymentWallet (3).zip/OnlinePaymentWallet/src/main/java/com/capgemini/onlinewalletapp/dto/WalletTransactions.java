package com.capgemini.onlinewalletapp.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

public class WalletTransactions implements Serializable{
	
	private int transactionId;
	private String description;
	private double amount;
	private double accountBalance;
	private LocalDateTime dateoftransaction;
	
	
	public WalletTransactions() {
		super();
		// TODO Auto-generated constructor stub
	}


	public WalletTransactions(int transactionId, String description, double amount, double accountBalance,
			LocalDateTime dateoftransaction) {
		super();
		this.transactionId = transactionId;
		this.description = description;
		this.amount = amount;
		this.accountBalance = accountBalance;
		this.dateoftransaction = dateoftransaction;
	}


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public double getAccountBalance() {
		return accountBalance;
	}


	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}


	public LocalDateTime getDateoftransaction() {
		return dateoftransaction;
	}


	public void setDateoftransaction(LocalDateTime dateoftransaction) {
		this.dateoftransaction = dateoftransaction;
	}
	
	
	

}
