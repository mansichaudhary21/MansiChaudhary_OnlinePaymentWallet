package com.capgemini.onlinewalletapp.dto;

import java.io.Serializable;
import java.util.*;

public class WalletAccounts implements Serializable{
	
	private int accountId;
	private static double accountBalance;
	private enum Status{
		ACTIVE,
		INACTIVE;
	}
	private List transactionHistory;
	
	
	public WalletAccounts() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public WalletAccounts( double accountBalance) {
		super();
		//this.accountId = accountId;
		this.accountBalance = accountBalance;
		//this.transactionHistory = transactionHistory;
	}


	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public List getTransactionHistory() {
		return transactionHistory;
	}

	public void setTransactionHistory(List transactionHistory) {
		this.transactionHistory = transactionHistory;
	}

	@Override
	
	public String toString()
	{
		return "Balance " + accountBalance;
	}
}
