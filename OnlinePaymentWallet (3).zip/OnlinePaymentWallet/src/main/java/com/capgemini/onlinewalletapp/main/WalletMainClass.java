package com.capgemini.onlinewalletapp.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;
import com.capgemini.onlinewalletapp.service.*;

//import serialex.Employee;

import com.capgemini.onlinewalletapp.dto.*;
//import java.util.Collections.*;

public class WalletMainClass implements Serializable {
	
	
	public static void main(String args[]) throws IOException
	{
		 int userId;
		 String userName;
		 String phoneNumber;
		 String password;
		 String loginName;
		 double accountBalance;
		 int ch;
		 char ch2;
		 Scanner sc1 = new Scanner(System.in);
		 Scanner sc = new Scanner(System.in);
		 WalletMainClass wmc = new WalletMainClass();
		 do 
		 {
			 System.out.println("1.Create Payment Wallet Account");
			 System.out.println("\n2.LogIn/SignIn");
			 System.out.println("\n3.Log Out");
			 System.out.println("\nEnter the choice: ");
			 ch = sc.nextInt();
			 switch(ch)
			 {
		 		case 1: 
		 			CreateWalletUser c = new CreateWalletUser();
		 			WalletUser w = new WalletUser();
		 			
		 			System.out.println("***************REGISTRATION PAGE*************");
		 			System.out.println("\nUser Id: ");
		 			userId = sc.nextInt();
		 			System.out.println("User Name: ");
		 			userName = sc1.nextLine();
		 			System.out.println("Contact No.: ");
		 			phoneNumber = sc1.nextLine();
		 			while(c.validate(phoneNumber)==false)
		 			{
		 				//w.setPhoneNumber();
		 				System.out.println("Contact No.:");
		 				phoneNumber=sc1.nextLine();
		 			}
		 			System.out.println("Login Name: ");
		 			loginName = sc1.nextLine();
		 			System.out.println("Password: ");
		 			password = sc1.nextLine();
		 			while(c.validatePass(password)==false)
		 			{
		 				//w.setPassword();
		 				System.out.println("Password:");
		 				password=sc1.nextLine();
		 			}
		 			WalletUser wu1 = new WalletUser(userId,userName,phoneNumber,password,loginName);
		 			LinkedHashSet<WalletUser> l= new LinkedHashSet();
		 			l.add(wu1);
		 			wmc.doSer(l);
		 			break;
		 	case 2:
		 			System.out.println("************LOGIN PAGE*************");
		 			
		 			int flag1 = wmc.doDeSer();
		 			if(flag1>0)
		 			{
		 				do
		 				{
		 					System.out.println("1.Add amount to Payment Wallet Account");
		 					System.out.println("\n2.Show Payment Wallet Account Balance");
		 					System.out.println("\n3.Transfer Funds to Another Wallet Account");
		 					//System.out.println("\n4.Log Out");
		 					System.out.println("\nEnter the choice: ");
		 					ch = sc.nextInt();
		 					switch(ch)
		 					{
		 						case 1: 
		 							System.out.println("Enter the amount:");
		 							double amt =  sc.nextDouble();
		 							AddAmount _objAddAmount = new AddAmount();
		 							double result =_objAddAmount.addBalance(amt);
		 							System.out.println("Current Balance:" + result);
		 							break;
		 						case 2:
		 							ShowBalance _objShowBal = new ShowBalance();
		 							_objShowBal.displayBalance();
		 							break;
		 						case 3:
		 							TransferFunds _objTransferFunds = new TransferFunds();
		 							_objTransferFunds.transferAmount();
		 							break;
		 						//case 4:
		 							//break;
		 						default:
		 							System.out.println("Please choose correct option.");
		 							break;
		 					}
		 					System.out.println("Do you want to perform more operation:Y/N");
		 					ch2 = sc1.next().charAt(0);
		 				}while(ch2 == 'Y' || ch2 == 'y');
		 			}
		 			else
		 			{
		 				System.out.println("Invalid LoginName/Password");
		 			}
		 			break;
		 	default:
		 			System.out.println("Please choose the right option...");
		 			break;
		 		
		 }
		 System.out.println("Do you want to perform more operation:Y/N");
		 ch2 = sc1.next().charAt(0);
	}while(ch2=='Y' || ch2 == 'y');
		 
	}
	
	public void doSer(LinkedHashSet<WalletUser> list) {
		try
        {    
          
            FileOutputStream file = new FileOutputStream("C:\\WalletApp\\LoginName.txt"); 
            ObjectOutputStream oas = new ObjectOutputStream(file); 
              
           
            oas.writeObject(list);
              
            oas.close(); 
            file.close(); 
              
            //System.out.println("Object has been serialized"); 
  
        } 
          
        catch(IOException ex) 
        { 
            ex.printStackTrace(); 
        } 
	}
	
	public int doDeSer() {
		int flag=0;
		try
        {    
			
          
            FileInputStream file = new FileInputStream("C:\\WalletApp\\LoginName.txt"); 
            ObjectInputStream oas = new ObjectInputStream(file); 
              
            LinkedHashSet<WalletUser> l;
			
				l = (LinkedHashSet<WalletUser>)oas.readObject();
				for(WalletUser wu:l) 
				{
					Scanner sc = new Scanner(System.in);
					System.out.println("Login name :");
					String n= sc.nextLine();
					System.out.println("Password:");
					String pass = sc.nextLine();
					if(wu.getLoginName().equals(n) && wu.getPassword().equals(pass)) {
						flag=1;
					}
					
				}
              oas.close(); 
              file.close(); 
              
              //System.out.println("Object has been Deserialized"); 
			 
        }  
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flag==1)
		{
			return flag;
		}
		return flag;
	}
	}
	
